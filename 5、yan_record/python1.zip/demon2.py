print('Adding numbers')
x=43+206
print('performing division')
y=x/0
print('math complete')   #print 用来测试找出错误