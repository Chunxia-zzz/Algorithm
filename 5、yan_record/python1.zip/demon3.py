py='hello world'
pyy='hi world'
print (py+pyy)
print(py+''+pyy) # + 加号 可以用来拼接